package com.asyncapi.model;


import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.annotation.processing.Generated;
import java.util.List;
import java.util.Objects;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.416Z")
public class AnonymousSchema9 {
    
    private @Valid String name;
    
    private @Valid String id;
    
    private @Valid String email;
    

    

    /**
     * Name of the customer
     */
    @JsonProperty("name")@NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    

    /**
     * Unique identifier for the customer
     */
    @JsonProperty("id")@NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    

    /**
     * Email address of the customer
     */
    @JsonProperty("email")@NotNull
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AnonymousSchema9 anonymousSchema9 = (AnonymousSchema9) o;
        return 
            Objects.equals(this.name, anonymousSchema9.name) &&
            Objects.equals(this.id, anonymousSchema9.id) &&
            Objects.equals(this.email, anonymousSchema9.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, id, email);
    }

    @Override
    public String toString() {
        return "class AnonymousSchema9 {\n" +
        
                "    name: " + toIndentedString(name) + "\n" +
                "    id: " + toIndentedString(id) + "\n" +
                "    email: " + toIndentedString(email) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
           return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}