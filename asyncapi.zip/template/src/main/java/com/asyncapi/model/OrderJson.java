package com.asyncapi.model;


import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.annotation.processing.Generated;
import java.util.List;
import java.util.Objects;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.494Z")
public class OrderJson {
    
    private @Valid java.time.OffsetDateTime orderDate;
    
    private @Valid double totalPrice;
    
    private @Valid String orderId;
    
    private @Valid List<AnonymousSchema5> items;
    
    private @Valid AnonymousSchema9 customer;
    
    public enum StatusEnum {
            
        PENDING(String.valueOf("pending")),
            
        PROCESSING(String.valueOf("processing")),
            
        SHIPPED(String.valueOf("shipped")),
            
        DELIVERED(String.valueOf("delivered")),
            
        CANCELLED(String.valueOf("cancelled"));
            
        private String value;

        StatusEnum (String v) {
            value = v;
        }

        public String value() {
            return value;
        }

        @Override
        @JsonValue
        public String toString() {
            return String.valueOf(value);
        }

        @JsonCreator
        public static StatusEnum fromValue(String value) {
            for ( StatusEnum b :  StatusEnum.values()) {
                if (Objects.equals(b.value, value)) {
                    return b;
                }
            }
            throw new IllegalArgumentException("Unexpected value '" + value + "'");
        }
    }

    private @Valid StatusEnum status;
    

    

    /**
     * Date and time when the order was placed
     */
    @JsonProperty("order_date")@NotNull
    public java.time.OffsetDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(java.time.OffsetDateTime orderDate) {
        this.orderDate = orderDate;
    }
    

    /**
     * Total price of the order
     */
    @JsonProperty("total_price")@NotNull
    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }
    

    /**
     * Unique identifier for the order
     */
    @JsonProperty("order_id")@NotNull
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    

    /**
     * Items included in the order
     */
    @JsonProperty("items")@NotNull
    public List<AnonymousSchema5> getItems() {
        return items;
    }

    public void setItems(List<AnonymousSchema5> items) {
        this.items = items;
    }
    

    
    @JsonProperty("customer")@NotNull
    public AnonymousSchema9 getCustomer() {
        return customer;
    }

    public void setCustomer(AnonymousSchema9 customer) {
        this.customer = customer;
    }
    

    /**
     * Status of the order
     */
    @JsonProperty("status")@NotNull
    public StatusEnum getStatus() {
        return status;
    }

    public void setStatus(StatusEnum status) {
        this.status = status;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        OrderJson orderJson = (OrderJson) o;
        return 
            Objects.equals(this.orderDate, orderJson.orderDate) &&
            Objects.equals(this.totalPrice, orderJson.totalPrice) &&
            Objects.equals(this.orderId, orderJson.orderId) &&
            Objects.equals(this.items, orderJson.items) &&
            Objects.equals(this.customer, orderJson.customer) &&
            Objects.equals(this.status, orderJson.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderDate, totalPrice, orderId, items, customer, status);
    }

    @Override
    public String toString() {
        return "class OrderJson {\n" +
        
                "    orderDate: " + toIndentedString(orderDate) + "\n" +
                "    totalPrice: " + toIndentedString(totalPrice) + "\n" +
                "    orderId: " + toIndentedString(orderId) + "\n" +
                "    items: " + toIndentedString(items) + "\n" +
                "    customer: " + toIndentedString(customer) + "\n" +
                "    status: " + toIndentedString(status) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
           return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}