package com.asyncapi.model;


import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.annotation.processing.Generated;
import java.util.List;
import java.util.Objects;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.516Z")
public class AnonymousSchema19 {
    
    private @Valid String country;
    
    private @Valid String city;
    
    private @Valid String street;
    
    private @Valid String state;
    
    private @Valid String postalCode;
    

    

    /**
     * Country
     */
    @JsonProperty("country")@NotNull
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    

    /**
     * City
     */
    @JsonProperty("city")@NotNull
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    

    /**
     * Street address
     */
    @JsonProperty("street")@NotNull
    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }
    

    /**
     * State or province
     */
    @JsonProperty("state")
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    

    /**
     * Postal or ZIP code
     */
    @JsonProperty("postal_code")
    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AnonymousSchema19 anonymousSchema19 = (AnonymousSchema19) o;
        return 
            Objects.equals(this.country, anonymousSchema19.country) &&
            Objects.equals(this.city, anonymousSchema19.city) &&
            Objects.equals(this.street, anonymousSchema19.street) &&
            Objects.equals(this.state, anonymousSchema19.state) &&
            Objects.equals(this.postalCode, anonymousSchema19.postalCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(country, city, street, state, postalCode);
    }

    @Override
    public String toString() {
        return "class AnonymousSchema19 {\n" +
        
                "    country: " + toIndentedString(country) + "\n" +
                "    city: " + toIndentedString(city) + "\n" +
                "    street: " + toIndentedString(street) + "\n" +
                "    state: " + toIndentedString(state) + "\n" +
                "    postalCode: " + toIndentedString(postalCode) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
           return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}