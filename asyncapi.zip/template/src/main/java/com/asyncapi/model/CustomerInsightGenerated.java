package com.asyncapi.model;

import javax.annotation.processing.Generated;

import jakarta.validation.Valid;
import java.util.Objects;
import java.util.List;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.187Z")
public class CustomerInsightGenerated {
    private @Valid CustomerInsight payload;

    public CustomerInsight getPayload() {
        return payload;
    }

    public void setPayload(CustomerInsight payload) {
        this.payload = payload;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CustomerInsightGenerated event = (CustomerInsightGenerated) o;
        return Objects.equals(this.payload, event.payload);
    }

    @Override
    public int hashCode() {
        return Objects.hash(payload);
    }

    @Override
    public String toString() {
        return "class CustomerInsightGenerated {\n" +
                "    payload: " + toIndentedString(payload) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}