package com.asyncapi.model;


import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.annotation.processing.Generated;
import java.util.List;
import java.util.Objects;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.588Z")
public class CustomerInsight {
    
    private @Valid String insightDescription;
    
    private @Valid String insightType;
    
    private @Valid String insightValue;
    
    private @Valid String customerId;
    
    private @Valid java.time.OffsetDateTime timestamp;
    

    

    /**
     * A brief description of the insight
     */
    @JsonProperty("insight_description")@NotNull
    public String getInsightDescription() {
        return insightDescription;
    }

    public void setInsightDescription(String insightDescription) {
        this.insightDescription = insightDescription;
    }
    

    /**
     * The type of insight (e.g., demographic, behavioral, transactional)
     */
    @JsonProperty("insight_type")@NotNull
    public String getInsightType() {
        return insightType;
    }

    public void setInsightType(String insightType) {
        this.insightType = insightType;
    }
    

    /**
     * The value or result of the insight
     */
    @JsonProperty("insight_value")@NotNull
    public String getInsightValue() {
        return insightValue;
    }

    public void setInsightValue(String insightValue) {
        this.insightValue = insightValue;
    }
    

    /**
     * The unique identifier of the customer
     */
    @JsonProperty("customer_id")@NotNull
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    

    /**
     * The timestamp when the insight was generated
     */
    @JsonProperty("timestamp")@NotNull
    public java.time.OffsetDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(java.time.OffsetDateTime timestamp) {
        this.timestamp = timestamp;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CustomerInsight customerInsight = (CustomerInsight) o;
        return 
            Objects.equals(this.insightDescription, customerInsight.insightDescription) &&
            Objects.equals(this.insightType, customerInsight.insightType) &&
            Objects.equals(this.insightValue, customerInsight.insightValue) &&
            Objects.equals(this.customerId, customerInsight.customerId) &&
            Objects.equals(this.timestamp, customerInsight.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(insightDescription, insightType, insightValue, customerId, timestamp);
    }

    @Override
    public String toString() {
        return "class CustomerInsight {\n" +
        
                "    insightDescription: " + toIndentedString(insightDescription) + "\n" +
                "    insightType: " + toIndentedString(insightType) + "\n" +
                "    insightValue: " + toIndentedString(insightValue) + "\n" +
                "    customerId: " + toIndentedString(customerId) + "\n" +
                "    timestamp: " + toIndentedString(timestamp) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
           return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}