package com.asyncapi.model;


import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.annotation.processing.Generated;
import java.util.List;
import java.util.Objects;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.312Z")
public class AnonymousSchema5 {
    
    private @Valid int quantity;
    
    private @Valid String itemId;
    
    private @Valid double price;
    

    

    /**
     * Quantity of the item ordered
     */
    @JsonProperty("quantity")@NotNull@Min(1)
    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
    

    /**
     * Unique identifier for the item
     */
    @JsonProperty("item_id")@NotNull
    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
    

    /**
     * Price per unit of the item
     */
    @JsonProperty("price")@NotNull
    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AnonymousSchema5 anonymousSchema5 = (AnonymousSchema5) o;
        return 
            Objects.equals(this.quantity, anonymousSchema5.quantity) &&
            Objects.equals(this.itemId, anonymousSchema5.itemId) &&
            Objects.equals(this.price, anonymousSchema5.price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(quantity, itemId, price);
    }

    @Override
    public String toString() {
        return "class AnonymousSchema5 {\n" +
        
                "    quantity: " + toIndentedString(quantity) + "\n" +
                "    itemId: " + toIndentedString(itemId) + "\n" +
                "    price: " + toIndentedString(price) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
           return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}