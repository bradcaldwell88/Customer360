package com.asyncapi.model;


import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import javax.annotation.processing.Generated;
import java.util.List;
import java.util.Objects;


@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.677Z")
public class CustomerJson {
    
    private @Valid AnonymousSchema19 address;
    
    private @Valid String phone;
    
    private @Valid String name;
    
    private @Valid String id;
    
    private @Valid String email;
    

    

    
    @JsonProperty("address")@NotNull
    public AnonymousSchema19 getAddress() {
        return address;
    }

    public void setAddress(AnonymousSchema19 address) {
        this.address = address;
    }
    

    /**
     * Phone number of the customer
     */
    @JsonProperty("phone")@Pattern(regexp="^&#92;&#92;+?[0-9]{1,3}-?[0-9]{3,}$")
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    

    /**
     * Name of the customer
     */
    @JsonProperty("name")@NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    

    /**
     * Unique identifier for the customer
     */
    @JsonProperty("id")@NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    

    /**
     * Email address of the customer
     */
    @JsonProperty("email")@NotNull
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CustomerJson customerJson = (CustomerJson) o;
        return 
            Objects.equals(this.address, customerJson.address) &&
            Objects.equals(this.phone, customerJson.phone) &&
            Objects.equals(this.name, customerJson.name) &&
            Objects.equals(this.id, customerJson.id) &&
            Objects.equals(this.email, customerJson.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(address, phone, name, id, email);
    }

    @Override
    public String toString() {
        return "class CustomerJson {\n" +
        
                "    address: " + toIndentedString(address) + "\n" +
                "    phone: " + toIndentedString(phone) + "\n" +
                "    name: " + toIndentedString(name) + "\n" +
                "    id: " + toIndentedString(id) + "\n" +
                "    email: " + toIndentedString(email) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
           return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}