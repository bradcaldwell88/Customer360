package com.asyncapi.service;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

import javax.annotation.processing.Generated;

@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.133Z")
@MessagingGateway
public interface PublisherService {

    
        
    
        
    
    @Gateway(requestChannel = "OutboundChannel")
    void (String data);
        
    
        
    
}
