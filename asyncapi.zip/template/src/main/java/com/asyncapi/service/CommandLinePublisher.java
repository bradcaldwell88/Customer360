package com.asyncapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.annotation.processing.Generated;
import java.util.Random;

@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.035Z")
@Component
public class CommandLinePublisher implements CommandLineRunner {

    @Autowired
    PublisherService publisherService;

    @Override
    public void run(String... args) {
        System.out.println("******* Sending message: *******");
        publisherService.("Hello World from acmeretail/c360/customerinsight/generated/v1/{insighttype}/{customerid}");
                
        System.out.println("Message sent");
    }
}
