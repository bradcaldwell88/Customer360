package com.asyncapi.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;


import javax.annotation.processing.Generated;

@Generated(value="com.asyncapi.generator.template.spring", date="2024-06-11T19:04:05.084Z")
@Service
public class MessageHandlerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageHandlerService.class);

    
    
    
    public void handle(Message<?> message) {
        LOGGER.info("handler acmeretail/onlineservices/order/created/v2/{regionId}/{orderId}");
        LOGGER.info(String.valueOf(message.getPayload().toString()));
    }
      
    
    
    
    
    
    public void handle(Message<?> message) {
        LOGGER.info("handler acmeretail/onlineservices/customer/updated/v2/{regionId}/{customerId}");
        LOGGER.info(String.valueOf(message.getPayload().toString()));
    }
      
    

}
